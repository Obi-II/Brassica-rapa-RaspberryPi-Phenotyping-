# Additional repository files — upload instructions

This is an **add-on**, not a replacement for the files already in your GitHub repository.

Already uploaded by the author: `capture.py`, `emergence_DAP_corrected.py`, growth-figure script and `README.md`. **Do not delete or replace those files.**

## Upload
1. Extract this ZIP on your computer.
2. In your GitHub repository, use **Add file → Upload files**. Upload the extracted folders/files while preserving their directory paths. GitHub web upload may not preserve folder hierarchy in all browsers; alternatively drag the extracted folders into the upload page, inspect the displayed paths, and commit. If paths flatten, upload files within their respective folders using GitHub's folder navigation, or use GitHub Desktop.
3. Do **not** upload the ZIP itself in place of its contents.
4. Keep the existing README. Add a link from it to `REPOSITORY_NOTES.md` if helpful.
5. Do not create a GitHub release or Zenodo DOI until the items in `REPOSITORY_NOTES.md` have been reviewed.

## Important
Original HSV extraction code and later QC improvements are separate. No ROI coordinates or measured leaf area/biomass values were modified by this packaging step. Figure 9B legacy script includes an older biomass analysis: use `analysis/validation/figure10_biomass.py` for the final figure 10. The daily JSONs omit June 21 (19 DAP); do not interpolate.
